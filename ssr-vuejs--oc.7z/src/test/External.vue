<template>
    <ExampleExternalComponent />
</template>

<script>
    import ExampleExternalComponent from 'example-external-component'

    export default {
        components: {
            ExampleExternalComponent
        }
    }
</script>
